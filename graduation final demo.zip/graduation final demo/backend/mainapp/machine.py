import joblib
try:
    # Use raw string to avoid escaping backslashes
    model_path = r'C:\Users\Sigma\OneDrive\Desktop\django project testing\backend\mainapp\models\cls.pkl'
    model = joblib.load(model_path)
except FileNotFoundError as e:
    print(f"Model file not found: {e}")
except Exception as e:
    print(f"An error occurred while loading the model: {e}")

def test(x_test):
    try:
        out = model.predict(x_test)
        print(out)
    except Exception as e:
        print(f"An error occurred during prediction: {e}")
    return out
 
 

# Example usage:
# Assuming x_test is a suitable input for the model
# x_test = ...
# test(x_test)
