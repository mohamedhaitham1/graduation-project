import re
from urllib.parse import unquote

def extract_features(input_link):
    features = {}

    # Decoding URL-encoded characters
    decoded_link = unquote(input_link)
    
    # Feature extraction
    features['Contains &lt'] = int('&lt;' in decoded_link)
    features['ScripTag'] = int('<script' in decoded_link.lower() or '</script>' in decoded_link.lower())
    features['Readable'] = int(any(c.isalpha() for c in decoded_link))
    features['Contains "><'] = int('"><' in decoded_link)
    features['Contains \'><'] = int("'><" in decoded_link)
    features['Contains And'] = int('&' in decoded_link)
    features['Contains Percentage'] = int('%' in decoded_link)
    features['Contains Slash'] = int('/' in decoded_link)
    features['Contains BackSlash'] = int('\\' in decoded_link)
    features['Contains Plus'] = int('+' in decoded_link)
    features['Contains Document'] = int('document' in decoded_link.lower())
    features['Contains Window'] = int('window' in decoded_link.lower())
    features['Contains Onload'] = int('onload' in decoded_link.lower())
    features['Contains Onerror'] = int('onerror' in decoded_link.lower())
    features['Contains DIV'] = int('<div' in decoded_link.lower() or '</div>' in decoded_link.lower())
    features['Contains iframe'] = int('<iframe' in decoded_link.lower() or '</iframe>' in decoded_link.lower())
    features['Contains img'] = int('<img' in decoded_link.lower())
    features['Contains SRC'] = int('src' in decoded_link.lower())
    features['Containss Var'] = int('var' in decoded_link.lower())
    features['Contains Eval'] = int('eval' in decoded_link.lower())
    features['Contains href'] = int('href' in decoded_link.lower())
    features['Contains Cookie'] = int('cookie' in decoded_link.lower())
    features['Contains StringfromCharCode'] = int('string.fromcharcode' in decoded_link.lower())
    features['Contains Single Quote'] = int("'" in decoded_link)
    features['Contains Question Mark'] = int('?' in decoded_link)
    features['Contains Exclamation Mark'] = int('!' in decoded_link)
    features['Contains Semicolon'] = int(';' in decoded_link)
    features['Contains HTTP'] = int('http' in decoded_link.lower())
    features['Contains JS'] = int('.js' in decoded_link.lower())
    features['Contains Hash'] = int('#' in decoded_link)
    features['Contains Equal'] = int('=' in decoded_link)
    features['Contains Open Bracket'] = int('[' in decoded_link)
    features['Contains Close Bracket'] = int(']' in decoded_link)
    features['Contains Duble Bracket'] = int(']]' in decoded_link or '[[' in decoded_link)
    features['Contains Dollar'] = int('$' in decoded_link)
    features['Contains Open Parenthesis'] = int('(' in decoded_link)
    features['Contains Close Parenthesis'] = int(')' in decoded_link)
    features['Contains Asterisk'] = int('*' in decoded_link)
    features['Contains Comma'] = int(',' in decoded_link)
    features['Contains Hyphen'] = int('-' in decoded_link)
    features['Contains Less Than'] = int('<' in decoded_link)
    features['Contains Greater Than'] = int('>' in decoded_link)
    features['Contains At'] = int('@' in decoded_link)
    features['Contains Underscore'] = int('_' in decoded_link)
    features['Contains location'] = int('location' in decoded_link.lower())
    features['Contains Search'] = int('search' in decoded_link.lower())
    features['Contains &#'] = int('&#' in decoded_link)
    features['Contains Colon'] = int(':' in decoded_link)
    features['Contains Dots'] = int('.' in decoded_link)
    features['Contains Open Brace'] = int('{' in decoded_link)
    features['Contains Close Brace'] = int('}' in decoded_link)
    features['Contains tilde'] = int('~' in decoded_link)
    features['Contains Spase'] = int(' ' in decoded_link)
    features['Contains Qutions'] = int('"' in decoded_link)
    features['Contains Grave'] = int('`' in decoded_link)
    features['Contains Duble Equals'] = int('==' in decoded_link)
    features['Contains Duble Slash'] = int('//' in decoded_link)
    features['Contains Vertical Bar'] = int('|' in decoded_link)
    features['Contains Power'] = int('^' in decoded_link)
    features['Contains Broken Bar'] = int('¦' in decoded_link)
    features['Contains Alert'] = int('alert' in decoded_link.lower())
    features['Contains Break Line'] = int('<br>' in decoded_link.lower() or '</br>' in decoded_link.lower())
    
    # Ratios
    letters = sum(c.isalpha() for c in decoded_link)
    numbers = sum(c.isdigit() for c in decoded_link)
    symbols = sum(not c.isalnum() for c in decoded_link)
    total_chars = len(decoded_link)
    
    features['Letters Ratio'] = letters / total_chars if total_chars > 0 else 0
    features['Numbuers Ratio'] = numbers / total_chars if total_chars > 0 else 0
    features['Symbols Ratio'] = symbols / total_chars if total_chars > 0 else 0
    
    return features

    
def format_features(features):
    # Convert the features dictionary to a list of feature values
    feature_list = [features[key] for key in features.keys()]
    return [feature_list]  # Return as a 2D list

def print_features(features):
    # Print feature values
   
    for key, value in features.items():
        print(f"{value}\t", end="")
        print(key)

    # Print a newline after printing all feature values
    print()

url = "http://example.com/test?name=value&script=<script>alert('XSS')</script>"
features = extract_features(url)
formatted_features = format_features(features)
print_features(features)