from django.shortcuts import render, HttpResponse, redirect
from .feature_extracrion import * 
from .machine import test
from .models import users_s, link_base

def home(request):
    return HttpResponse('hello world')

def signup(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')

        new_user = users_s(name=first_name, mail=email, password=password, last_name=last_name)
        new_user.save()
        return redirect("/index.html")
    return render(request, 'sign up.html')

def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        return redirect("/index.html")
    return render(request, 'login page.html')

def index(request):
    detection_result = ""
    input_link = ""
    if request.method == 'POST':
        input_link = request.POST.get('inputText')
        
        x_test = extract_features(input_link)
        formatted_features = format_features(x_test)
        state = test(formatted_features)

        if state == [1]:
            new_input = link_base(input_link=input_link)
            new_input.save()
            detection_result = "Potential XSS detected!"
        else:
            detection_result = "No XSS detected."

    return render(request, 'index.html', {'detection_result': detection_result, 'input_link': input_link})
