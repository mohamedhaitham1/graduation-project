from django.urls import path
from . import views
urlpatterns=[
    #path("",views.home,name="home"),
    path("index.html/",views.index,name="index"),
    path("",views.signup,name="signup"),
    #path("",views.test_link,name="test_link")
    path("login page.html/",views.login,name="login"),



]