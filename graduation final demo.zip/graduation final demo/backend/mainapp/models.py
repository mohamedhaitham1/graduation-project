from django.db import models

class users_s(models.Model):
    name=models.CharField(max_length=100)
    mail=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)

class link_base(models.Model):
    #user=models.ForeignKey(users_s,on_delete=models.CASCADE)
    input_link=models.CharField(max_length=200)
    #result = models.ImageField(null=True, blank=True)
# Create your models here.
