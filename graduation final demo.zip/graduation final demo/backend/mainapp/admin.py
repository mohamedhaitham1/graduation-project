from django.contrib import admin
from .models import users_s
from .models import link_base


admin.site.register(users_s)
admin.site.register(link_base)

# Register your models here.
